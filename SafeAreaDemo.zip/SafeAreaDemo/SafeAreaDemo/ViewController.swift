

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var navigationBar: NavigationBar!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
    }

    override func viewWillAppear(_ animated: Bool) {
           
           if #available(iOS 13.0, *) {
               let app = UIApplication.shared
               let statusBarHeight: CGFloat = app.statusBarFrame.size.height
               
               let statusbarView = UIView()
               statusbarView.backgroundColor = UIColor.systemYellow
               view.addSubview(statusbarView)
             
               statusbarView.translatesAutoresizingMaskIntoConstraints = false
               statusbarView.heightAnchor
                   .constraint(equalToConstant: statusBarHeight).isActive = true
               statusbarView.widthAnchor
                   .constraint(equalTo: view.widthAnchor, multiplier: 1.0).isActive = true
               statusbarView.topAnchor
                   .constraint(equalTo: view.topAnchor).isActive = true
               statusbarView.centerXAnchor
                   .constraint(equalTo: view.centerXAnchor).isActive = true
             
           } else {
               let statusBar = UIApplication.shared.value(forKeyPath: "statusBarWindow.statusBar") as? UIView
               statusBar?.backgroundColor = UIColor.systemYellow
           }
           
           self.view.bringSubviewToFront(navigationBar)

       }
       override var preferredStatusBarStyle : UIStatusBarStyle {
             // return UIStatusBarStyle.lightContent
              return UIStatusBarStyle.default   // Make dark again
          }
}

